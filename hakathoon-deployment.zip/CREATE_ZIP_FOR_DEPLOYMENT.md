# 📦 إنشاء ملف ZIP للنشر على Render

## الطريقة السريعة (بدون Git)

إذا لم يكن Git مثبتاً، يمكنك إنشاء ملف ZIP ورفعه مباشرة إلى Render.

---

## 📋 خطوات إنشاء ZIP

### 1. استبعاد الملفات غير الضرورية

قبل إنشاء ZIP، تأكد من استبعاد:
- ❌ `backend/venv/` - البيئة الافتراضية
- ❌ `backend/__pycache__/` - ملفات Python المؤقتة
- ❌ `backend/tests/__pycache__/` - ملفات الاختبار المؤقتة
- ❌ `.ipynb_checkpoints/` - ملفات Jupyter
- ❌ `*.pyc` - ملفات Python المترجمة

**ملاحظة**: ملف `.gitignore` موجود بالفعل ويستبعد هذه الملفات تلقائياً.

---

### 2. إنشاء ZIP يدوياً

#### الطريقة A: استخدام Windows Explorer

1. **افتح مجلد المشروع**
   ```
   C:\Users\waaad\OneDrive - ek.com.sa\Documents\hakathoon
   ```

2. **اختر الملفات والمجلدات التالية فقط**:
   - ✅ `backend/` (بدون `venv/` و `__pycache__/`)
   - ✅ `frontend/`
   - ✅ `ml/`
   - ✅ `requirements.txt`
   - ✅ `render.yaml`
   - ✅ `.gitignore`
   - ✅ `DEPLOYMENT.md`
   - ✅ أي ملفات `.md` أخرى

3. **اضغط بزر الماوس الأيمن** → **Send to** → **Compressed (zipped) folder**

4. **سمّ الملف**: `hakathoon-deployment.zip`

---

#### الطريقة B: استخدام PowerShell (موصى به)

```powershell
# الانتقال إلى المجلد الأب
cd "C:\Users\waaad\OneDrive - ek.com.sa\Documents"

# إنشاء ZIP باستثناء الملفات غير الضرورية
Compress-Archive -Path `
    hakathoon\backend\*.py, `
    hakathoon\backend\ml, `
    hakathoon\frontend, `
    hakathoon\ml, `
    hakathoon\requirements.txt, `
    hakathoon\render.yaml, `
    hakathoon\.gitignore, `
    hakathoon\*.md `
    -DestinationPath hakathoon-deployment.zip -Force
```

**ملاحظة**: قد تحتاج لتعديل هذا الأمر حسب هيكل ملفاتك.

---

### 3. التحقق من محتويات ZIP

افتح ملف ZIP وتأكد من:
- ✅ وجود `backend/main.py`
- ✅ وجود `backend/engine.py`
- ✅ وجود `backend/models.py`
- ✅ وجود `backend/storage.py`
- ✅ وجود `ml/models/isoforest_absher.pkl`
- ✅ وجود `requirements.txt`
- ✅ وجود `render.yaml`
- ❌ عدم وجود `backend/venv/`
- ❌ عدم وجود `__pycache__/`

---

## 🚀 رفع ZIP إلى Render

### الطريقة 1: عبر GitHub (موصى به)

1. **ارفع ZIP إلى GitHub**
   - اذهب إلى https://github.com/new
   - أنشئ مستودع جديد
   - اضغط "uploading an existing file"
   - اسحب ملف ZIP (أو استخرج الملفات وارفعها)
   - اضغط "Commit changes"

2. **ربط Render بـ GitHub**
   - اذهب إلى Render Dashboard
   - اختر "New Web Service"
   - اختر المستودع من GitHub
   - Render سيكتشف `render.yaml` تلقائياً

---

### الطريقة 2: رفع مباشر إلى Render

1. **استخرج ملف ZIP**
   - استخرج جميع الملفات من ZIP
   - تأكد من الحفاظ على الهيكل

2. **ارفع إلى Render**
   - اذهب إلى Render Dashboard
   - اختر "Manual Deploy"
   - ارفع الملفات (أو استخدم Git إذا كان متاحاً)

---

## 📁 هيكل ZIP المطلوب

```
hakathoon-deployment.zip
├── backend/
│   ├── main.py
│   ├── engine.py
│   ├── models.py
│   ├── storage.py
│   └── ml/
│       └── models/
│           └── isoforest_absher.pkl
├── frontend/
│   ├── public/
│   │   ├── *.html
│   └── js/
│       └── events.js
├── ml/
│   └── models/
│       └── isoforest_absher.pkl
├── requirements.txt
├── render.yaml
├── .gitignore
└── *.md (optional)
```

---

## ✅ Checklist قبل إنشاء ZIP

- [ ] تأكد من وجود جميع الملفات المطلوبة
- [ ] تأكد من استبعاد `venv/` و `__pycache__/`
- [ ] تحقق من وجود `requirements.txt`
- [ ] تحقق من وجود `render.yaml`
- [ ] تحقق من وجود `ml/models/isoforest_absher.pkl`
- [ ] تحقق من حجم ZIP (يجب أن يكون < 100 MB)

---

## 🆘 حل المشاكل

### إذا كان حجم ZIP كبير جداً:

1. **تحقق من استبعاد `venv/`**
   ```powershell
   # تحقق من حجم venv
   Get-ChildItem -Path "backend\venv" -Recurse | Measure-Object -Property Length -Sum
   ```

2. **استبعد الملفات الكبيرة**
   - تأكد من عدم تضمين ملفات `.mp4` أو `.mov` الكبيرة
   - استبعد أي ملفات وسائط غير ضرورية

### إذا فشل النشر:

1. **تحقق من `render.yaml`**
   - تأكد من صحة المسارات
   - تأكد من صحة الأمر: `python backend/main.py`

2. **تحقق من `requirements.txt`**
   - تأكد من وجود جميع التبعيات
   - تأكد من عدم وجود أخطاء إملائية

---

## 💡 نصيحة

**الأفضل**: تثبيت Git واستخدامه بدلاً من ZIP. Git أسهل وأكثر أماناً للنشر المستمر.

راجع `GIT_SETUP_GUIDE.md` لمعرفة كيفية تثبيت Git.

---

**جاهز للنشر!** 🚀

