# 📚 وثيقة المشروع الشاملة - Digital Threat Fingerprint

## 🎯 نظرة عامة على المشروع

**Digital Threat Fingerprint** هو نظام متكامل لاكتشاف التهديدات السلوكية عبر المنصات الحكومية السعودية. يعمل النظام على مراقبة سلوك المستخدمين في الوقت الفعلي، وتحليل الأنماط المشبوهة، وإنشاء "بصمات تهديد" (Threat Fingerprints) يمكن استخدامها لمنع الوصول عبر المنصات المختلفة.

---

## 🏗️ البنية المعمارية للمشروع

### الهيكل العام:
```
hakathoon/
├── backend/              # الخادم الخلفي (Flask)
│   ├── main.py          # نقطة الدخول الرئيسية و API endpoints
│   ├── engine.py        # محرك تحليل التهديدات
│   ├── models.py        # نماذج البيانات (Event, ThreatFingerprint)
│   ├── storage.py       # التخزين في الذاكرة
│   └── venv/            # البيئة الافتراضية
├── frontend/            # الواجهة الأمامية
│   ├── public/          # صفحات HTML
│   │   ├── dashboard.html
│   │   ├── absher-login.html
│   │   ├── tawakkalna-login.html
│   │   └── health-portal.html
│   └── js/              # ملفات JavaScript
│       └── events.js    # تتبع الأحداث المركزي
└── ml/                  # نماذج التعلم الآلي
    └── models/
        └── isoforest_absher.pkl
```

---

## 📋 المراحل التطويرية - شرح تفصيلي

---

## المرحلة 1: إعداد البنية الأساسية (Backend Foundation)

### 1.1 إنشاء نماذج البيانات (`models.py`)

**الهدف:** تعريف هياكل البيانات الأساسية للنظام.

#### Event Model:
```python
@dataclass
class Event:
    event_type: str          # نوع الحدث (login_attempt, download_file, etc.)
    user_id: str             # معرف المستخدم
    device_id: str           # معرف الجهاز
    timestamp1: datetime      # وقت الحدث
    platform: str            # المنصة (tawakkalna, absher, etc.)
    ip_address: str          # عنوان IP
    user_agent: str          # معلومات المتصفح
```

**السبب:** كل حدث يمثل إجراءً يقوم به المستخدم. هذه البيانات ضرورية لتحليل السلوك.

#### ThreatFingerprint Model:
```python
@dataclass
class ThreatFingerprint:
    fingerprint_id: str      # معرف فريد للبصمة
    risk_score: int          # درجة الخطورة (0-100)
    user_id: str             # المستخدم المرتبط
    status: str              # الحالة (ACTIVE, BLOCKED, CLEARED)
    behavioral_features: Dict # الخصائص السلوكية
    device_id: str           # معرف الجهاز
    ip_address: str          # عنوان IP
    user_agent: str          # معلومات المتصفح
```

**السبب:** البصمة تمثل تهديداً محتملاً. عندما يتم اكتشاف سلوك مشبوه، يتم إنشاء بصمة يمكن استخدامها لمنع الوصول لاحقاً.

---

### 1.2 نظام التخزين (`storage.py`)

**الهدف:** إدارة التخزين في الذاكرة للأحداث والبصمات.

#### المتغيرات الرئيسية:
```python
EVENTS_STORE = []           # قائمة جميع الأحداث
FINGERPRINTS_STORE = []     # قائمة جميع البصمات
```

#### الدوال الأساسية:
- `store_event(event)` - حفظ حدث جديد
- `get_fingerprints()` - جلب جميع البصمات
- `update_fingerprint_status()` - تحديث حالة البصمة
- `clear_user_fingerprints()` - مسح بصمات مستخدم
- `delete_fingerprint()` - حذف بصمة نهائياً

**السبب:** نحتاج تخزين مؤقت في الذاكرة للعرض التوضيحي. في الإنتاج، سيتم استبدال هذا بقاعدة بيانات.

---

### 1.3 محرك تحليل التهديدات (`engine.py`)

**الهدف:** تحليل الأحداث وإنشاء بصمات التهديد عند اكتشاف سلوك مشبوه.

#### العملية الرئيسية (`process_event`):

**الخطوة 1: حساب الخصائص السلوكية**
```python
behavioral_features = calculate_behavioral_features(
    user_id, device_id, current_time
)
```

**ما يتم حسابه:**
- `total_events` - إجمالي الأحداث
- `events_per_minute` - معدل الأحداث في الدقيقة
- `update_mobile_attempt_count` - محاولات تحديث رقم الجوال
- `fast_drain` - استنزاف سريع للخدمات
- وغيرها...

**السبب:** نحتاج قياسات رقمية لوصف السلوك.

**الخطوة 2: حساب درجة الخطورة (ML + Rules)**

**أ) نموذج التعلم الآلي (Isolation Forest):**
```python
if model_loaded:
    risk_score = model.predict(features)
```

**ب) قواعد الكشف (Fallback Rules):**
```python
# كشف النقرات السريعة
recent = [e for e in EVENTS_STORE[-10:]]
if len(recent) >= 8:
    delta = (recent[-1].timestamp1 - recent[0].timestamp1).total_seconds()
    if delta <= 3:  # 8 أحداث في 3 ثوانٍ
        should_create_fingerprint = True
        risk_score = max(risk_score, 95)
```

**السبب:** 
- ML يكتشف الأنماط المعقدة
- القواعد تضمن الكشف حتى لو فشل ML

**الخطوة 3: إنشاء البصمة**
```python
if should_create_fingerprint and risk_score >= 80:
    fingerprint = ThreatFingerprint(
        fingerprint_id=f"fp-{uuid.uuid4().hex[:12]}",
        risk_score=risk_score,
        user_id=event.user_id,
        status="ACTIVE",
        behavioral_features=behavioral_features,
        device_id=event.device_id,
        ip_address=event.ip_address,
        user_agent=event.user_agent
    )
    store_fingerprint(fingerprint)
```

**السبب:** عندما يكون السلوك مشبوهاً بدرجة كافية، نحفظ البصمة للاستخدام لاحقاً.

---

### 1.4 API Endpoints (`main.py`)

**الهدف:** توفير واجهات برمجية للواجهة الأمامية.

#### POST `/api/v1/event`
**الوظيفة:** استقبال الأحداث من الواجهة الأمامية

**العملية:**
1. استقبال البيانات من الطلب
2. استخراج IP و User-Agent من الطلب
3. إنشاء كائن Event
4. حفظ الحدث
5. معالجة الحدث عبر `process_event()`
6. إرجاع النتيجة

**السبب:** هذه هي نقطة الدخول الرئيسية لجميع الأحداث.

#### GET `/api/v1/fingerprints`
**الوظيفة:** جلب جميع البصمات للعرض في Dashboard

**السبب:** Dashboard يحتاج عرض البصمات.

#### POST `/api/v1/check-and-login`
**الوظيفة:** التحقق من وجود بصمة نشطة قبل السماح بتسجيل الدخول

**العملية:**
```python
is_fingerprinted = is_user_fingerprinted(user_id)
if is_fingerprinted:
    return {"status": "blocked", "allowed": False}, 403
else:
    return {"status": "ok", "allowed": True}, 200
```

**السبب:** هذا هو القلب الأمني - يمنع المستخدمين المشبوهين من الدخول.

#### POST `/api/v1/confirm-threat`
**الوظيفة:** تأكيد التهديد (تغيير الحالة إلى BLOCKED)

**السبب:** المشغل يحتاج تأكيد التهديدات يدوياً.

#### POST `/api/v1/unblock-user`
**الوظيفة:** إزالة المنع (تغيير الحالة إلى CLEARED)

**السبب:** المشغل يحتاج إزالة المنع عن المستخدمين.

#### POST `/api/v1/delete-fingerprint`
**الوظيفة:** حذف بصمة نهائياً

**السبب:** المشغل يحتاج حذف البصمات الخاطئة.

---

## المرحلة 2: الواجهة الأمامية - تتبع الأحداث المركزي

### 2.1 نظام التتبع المركزي (`events.js`)

**الهدف:** إنشاء نظام موحد لتتبع الأحداث من جميع الصفحات.

#### 2.1.1 تعريفات DEMO:
```javascript
const DEMO_USER_ID = "user-8456123848";     // معرف ثابت للعرض التوضيحي
const DEMO_DEVICE_ID = "device-demo-01";    // معرف جهاز ثابت
```

**السبب:** في العرض التوضيحي، نريد نفس المستخدم عبر جميع المنصات لاختبار الحجب عبر المنصات.

#### 2.1.2 دالة sendEvent العامة:
```javascript
function sendEvent(eventType, serviceName = null, extra = {}) {
    const payload = {
        event_type: eventType,
        user_id: getCurrentUserId(),
        device_id: getCurrentDeviceId(),
        timestamp1: new Date().toISOString(),
        service_name: serviceName,
        platform: getCurrentPlatform(),
        ...extra
    };
    
    return fetch(`${API_BASE}/api/v1/event`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    });
}
```

**السبب:** 
- دالة واحدة لجميع الأحداث
- تلقائياً تضيف user_id, device_id, platform
- سهلة الاستخدام من أي صفحة

#### 2.1.3 كاشف النقرات السريعة:
```javascript
function attachRapidClickDetector(element, options = {}) {
    let clickTimes = [];
    
    element.addEventListener("click", () => {
        const now = Date.now();
        clickTimes.push(now);
        
        // إزالة النقرات القديمة
        clickTimes = clickTimes.filter(t => now - t <= windowLongMs);
        
        const clicksShort = clickTimes.filter(t => now - t <= 1000).length;
        
        if (clicksShort >= 5) {  // 5 نقرات في ثانية واحدة
            sendEvent("ui_suspicious_pattern", null, {
                pattern: "rapid_clicks",
                clicks_short: clicksShort
            });
        }
    });
}
```

**السبب:** كشف تلقائي للهجمات التي تعتمد على النقرات السريعة.

#### 2.1.4 الربط التلقائي:
```javascript
window.addEventListener("DOMContentLoaded", () => {
    // ربط تلقائي لجميع الأزرار المميزة بـ data-track-service
    document.querySelectorAll("[data-track-service]").forEach(btn => {
        attachRapidClickDetector(btn);
        btn.addEventListener("click", () => {
            const serviceName = btn.getAttribute("data-track-service");
            sendEvent("view_service", serviceName);
        });
    });
});
```

**السبب:** لا حاجة لكتابة كود لكل زر - يعمل تلقائياً.

---

## المرحلة 3: صفحات تسجيل الدخول

### 3.1 صفحة توكلنا (`tawakkalna-login.html`)

**الهدف:** محاكاة صفحة تسجيل الدخول في توكلنا.

#### الميزات:
1. **نموذج تسجيل الدخول:**
   - حقول: رقم الهوية، تاريخ الميلاد
   - زر تسجيل الدخول

2. **إرسال الأحداث:**
   ```javascript
   sendEvent('login_attempt', null, { page: 'tawakkalna' });
   // بعد النجاح:
   sendEvent('login_success', null, { page: 'tawakkalna' });
   ```

3. **التحقق من الحجب:**
   ```javascript
   const response = await fetch(`${API_BASE}/api/v1/check-and-login`, {
       method: 'POST',
       body: JSON.stringify({ user_id: getCurrentUserId() })
   });
   
   if (response.status === 403) {
       showBlockedOverlay();  // عرض رسالة الحجب
   }
   ```

**السبب:** نحتاج محاكاة منصة حقيقية لاختبار النظام.

---

### 3.2 صفحة أبشر (`absher-login.html`)

**الهدف:** محاكاة صفحة تسجيل الدخول في أبشر مع لوحة خدمات.

#### الميزات:

1. **نموذج تسجيل الدخول:**
   - حقول: اسم المستخدم، كلمة المرور
   - زر تسجيل الدخول

2. **لوحة الخدمات (بعد النجاح):**
   - **خدمات المرور:**
     - تفويض مركبة
     - المخالفات المرورية
     - تقارير الحوادث
   
   - **الخدمات الشخصية:**
     - الهوية الرقمية
     - خدمة بياناتي
     - سجل الأسرة
     - سجل السفر

3. **كل زر خدمة:**
   ```html
   <button class="service-btn" 
           data-track-service="vehicle_authorization"
           onclick="handleServiceClick('vehicle_authorization', 'تفويض مركبة')">
       فتح الخدمة
   </button>
   ```
   
   **يعمل تلقائياً:**
   - يرسل حدث `view_service`
   - يدعم كشف النقرات السريعة

4. **Overlay الحجب:**
   ```javascript
   function showBlockOverlay(message) {
       // overlay كامل الشاشة مع رسالة الحجب
   }
   ```

**السبب:** نحتاج منصة ثانية لاختبار الحجب عبر المنصات.

---

### 3.3 صفحة المنصة الصحية (`health-portal.html`)

**الهدف:** محاكاة منصة صحية مع خدمات التحميل.

#### الميزات:

1. **أزرار تحميل الخدمات:**
   - تقرير المختبر 1
   - تقرير المختبر 2
   - تقرير الأشعة
   - السجل الطبي الكامل
   - شهادة التطعيم

2. **زر محاكاة الهجوم:**
   ```javascript
   function simulateMassDownloadAttack() {
       // إرسال 20 حدث download_file بسرعة
       for (let i = 0; i < 20; i++) {
           setTimeout(() => {
               sendEvent("download_file", serviceName);
           }, i * 100);  // كل 100ms
       }
   }
   ```

**السبب:** نحتاج صفحة لاختبار هجمات التحميل الجماعي.

---

## المرحلة 4: لوحة التحكم الموحدة (Dashboard)

### 4.1 توحيد Dashboards (`dashboard.html`)

**الهدف:** دمج dashboard العرض و dashboard الإدارة في صفحة واحدة.

#### التبويبات:

**1. تبويب العرض:**
- جدول بسيط بجميع البصمات
- بطاقات إحصائية:
  - إجمالي البصمات
  - عالية الخطورة (>= 80)
  - متوسطة الخطورة (50-79)

**2. تبويب الإدارة (SOC Admin):**
- جدول كامل مع جميع التفاصيل
- أزرار الإجراءات:
  - 🔓 إزالة المنع (CLEARED)
  - ✅ تأكيد التهديد (BLOCKED)
  - 🗑️ حذف البصمة

#### الميزات:

1. **تحديث تلقائي:**
   ```javascript
   setInterval(() => {
       loadFingerprints();
   }, 5000);  // كل 5 ثوانٍ
   ```

2. **إشعارات البصمات الجديدة:**
   ```javascript
   const newFingerprints = fingerprints.filter(
       fp => !previousFingerprintIds.has(fp.fingerprint_id)
   );
   if (newFingerprints.length > 0) {
       showNewFingerprintNotification(newFingerprints);
   }
   ```

3. **عرض الخصائص السلوكية:**
   ```javascript
   function formatBehavioralFeatures(features) {
       return Object.entries(features)
           .map(([key, value]) => `${key}: ${value}`)
           .join(', ');
   }
   ```

**السبب:** مشغل واحد يحتاج عرض وإدارة في مكان واحد.

---

## المرحلة 5: سيناريو العرض التوضيحي الكامل

### 5.1 السيناريو:

#### الخطوة 1: تسجيل الدخول في توكلنا
1. المستخدم يفتح `tawakkalna-login.html`
2. يسجل الدخول بنجاح
3. النظام يرسل:
   - `login_attempt`
   - `login_success`

#### الخطوة 2: سلوك مشبوه في المنصة الصحية
1. المستخدم يفتح `health-portal.html`
2. ينقر على زر "محاكاة هجوم التحميل الجماعي"
3. النظام يرسل:
   - 20 حدث `download_file` في ثانيتين
   - حدث `ui_suspicious_pattern` مع `pattern: "mass_download"`

#### الخطوة 3: إنشاء البصمة
1. Backend يستقبل الأحداث
2. `engine.py` يحسب الخصائص السلوكية:
   - `total_events: 20+`
   - `events_per_minute: 600+`
   - `fast_drain: true`
3. ML أو القواعد تكتشف التهديد:
   - `risk_score: 95`
   - `should_create_fingerprint: true`
4. يتم إنشاء بصمة:
   ```python
   fingerprint = ThreatFingerprint(
       fingerprint_id="fp-abc123",
       risk_score=95,
       user_id="user-8456123848",
       status="ACTIVE",
       device_id="device-demo-01",
       ip_address="127.0.0.1",
       user_agent="Mozilla/5.0...",
       behavioral_features={...}
   )
   ```

#### الخطوة 4: عرض البصمة في Dashboard
1. المشغل يفتح `dashboard.html`
2. يرى البصمة الجديدة في الجدول
3. يرى:
   - درجة الخطورة: 95
   - الحالة: ACTIVE
   - الخصائص السلوكية
   - معلومات الجهاز/الشبكة

#### الخطوة 5: محاولة الدخول إلى أبشر
1. نفس المستخدم يفتح `absher-login.html`
2. يحاول تسجيل الدخول
3. Frontend يستدعي:
   ```javascript
   fetch(`${API_BASE}/api/v1/check-and-login`, {
       method: 'POST',
       body: JSON.stringify({ user_id: "user-8456123848" })
   })
   ```
4. Backend يتحقق:
   ```python
   is_fingerprinted = is_user_fingerprinted("user-8456123848")
   # Returns True (يوجد بصمة ACTIVE)
   ```
5. Backend يرد:
   ```json
   {
       "status": "blocked",
       "allowed": false,
       "message": "تم حجب دخولك مؤقتاً..."
   }
   ```
6. Frontend يعرض overlay الحجب:
   ```
   🚫 تم حجب دخولك
   تم حجب دخولك مؤقتاً بسبب سلوك مشبوه تم رصده على منصة حكومية أخرى.
   ```

#### الخطوة 6: إدارة البصمة
1. المشغل في Dashboard:
   - **تأكيد التهديد:** يغير الحالة إلى BLOCKED
   - **إزالة المنع:** يغير الحالة إلى CLEARED
   - **حذف:** يحذف البصمة نهائياً

---

## المرحلة 6: الميزات الأمنية المتقدمة

### 6.1 كشف النقرات السريعة

**كيف يعمل:**
1. كل زر مرتبط بـ `attachRapidClickDetector()`
2. عند كل نقرة، يتم حفظ الوقت
3. إذا كانت النقرات:
   - >= 5 في ثانية واحدة، أو
   - >= 15 في 5 ثوانٍ
4. يتم إرسال حدث `ui_suspicious_pattern`

**السبب:** الهجمات غالباً تستخدم نقرات سريعة متكررة.

---

### 6.2 الحجب عبر المنصات

**كيف يعمل:**
1. جميع المنصات تستخدم نفس `DEMO_USER_ID`
2. عندما يتم إنشاء بصمة في توكلنا
3. أبشر يتحقق من نفس `user_id`
4. إذا وجد بصمة ACTIVE → حجب

**السبب:** المهاجم قد يحاول استخدام منصات مختلفة.

---

### 6.3 تتبع معلومات الجهاز/الشبكة

**ما يتم تتبعه:**
- `device_id` - معرف الجهاز
- `ip_address` - عنوان IP
- `user_agent` - معلومات المتصفح
- `platform` - المنصة (tawakkalna/absher)

**السبب:** تساعد في ربط الأحداث بنفس المستخدم/الجهاز.

---

## المرحلة 7: تحسينات الأداء والموثوقية

### 7.1 CORS Configuration

**المشكلة:** المتصفح يمنع الطلبات من منافذ مختلفة.

**الحل:**
```python
CORS(app, resources={
    r"/api/*": {
        "origins": "*",
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})
```

**السبب:** Frontend على port 5000 و Backend على port 5000 (نفس المنفذ في هذا المشروع).

---

### 7.2 API_BASE الديناميكي

**المشكلة:** Hardcoded `http://localhost:5000` لا يعمل مع `127.0.0.1`.

**الحل:**
```javascript
const API_BASE = `${window.location.protocol}//${window.location.hostname}:5000`;
```

**السبب:** يعمل مع أي hostname.

---

### 7.3 DEMO_MODE

**الهدف:** إخفاء الإشعارات في العرض التوضيحي.

```javascript
const DEMO_MODE = true;

function showNotification(message, type) {
    if (DEMO_MODE) {
        console.log("[DEMO_NOTIFICATION_SUPPRESSED]", message);
        return;  // لا تظهر للمستخدم
    }
    // عرض الإشعار...
}
```

**السبب:** لا نريد إزعاج الجمهور بالإشعارات.

---

## المرحلة 8: الاختبارات والتحقق

### 8.1 اختبار تدفق الأحداث

**الخطوات:**
1. فتح صفحة توكلنا
2. تسجيل الدخول
3. فتح Console → التحقق من الأحداث المرسلة
4. فتح Backend logs → التحقق من استقبال الأحداث

**النتيجة المتوقعة:**
```
📥 [EVENT RECEIVED] Type: login_attempt, User: user-8456123848...
📥 [EVENT RECEIVED] Type: login_success, User: user-8456123848...
```

---

### 8.2 اختبار إنشاء البصمة

**الخطوات:**
1. فتح health-portal
2. تفعيل هجوم التحميل الجماعي
3. فتح Dashboard
4. التحقق من ظهور بصمة جديدة

**النتيجة المتوقعة:**
- بصمة جديدة في الجدول
- `risk_score >= 80`
- `status: "ACTIVE"`
- `behavioral_features` تحتوي على بيانات

---

### 8.3 اختبار الحجب عبر المنصات

**الخطوات:**
1. إنشاء بصمة في توكلنا
2. محاولة الدخول إلى أبشر
3. التحقق من ظهور overlay الحجب

**النتيجة المتوقعة:**
- `check-and-login` يرجع `403`
- Overlay يظهر مع رسالة الحجب
- لا يمكن تسجيل الدخول

---

## 📊 ملخص التدفق الكامل

```
[Frontend]                    [Backend]                    [Storage]
     |                            |                            |
     |-- login_attempt ---------->|                            |
     |                            |-- store_event() ---------->|
     |                            |-- process_event()         |
     |                            |   |                        |
     |                            |   |-- calculate_features() |
     |                            |   |-- ML prediction        |
     |                            |   |-- Rules check          |
     |                            |   |                        |
     |                            |   |-- create_fingerprint() |
     |                            |   |                        |
     |                            |   |-- store_fingerprint() ->|
     |                            |                            |
     |<-- fingerprint_generated --|                            |
     |                            |                            |
     |-- check-and-login -------->|                            |
     |                            |-- is_user_fingerprinted()  |
     |                            |   |                        |
     |                            |   |-- check FINGERPRINTS_STORE
     |                            |                            |
     |<-- blocked (403) ----------|                            |
     |                            |                            |
     |-- showBlockOverlay()       |                            |
```

---

## 🔑 المفاهيم الأساسية

### 1. Event (الحدث)
- أي إجراء يقوم به المستخدم
- يتم إرساله إلى Backend فوراً
- يحتوي على: نوع الحدث، المستخدم، الجهاز، الوقت، المنصة

### 2. Behavioral Features (الخصائص السلوكية)
- قياسات رقمية للسلوك
- مثال: `events_per_minute: 150`
- تستخدم في ML و Rules

### 3. Threat Fingerprint (بصمة التهديد)
- تمثل تهديداً محتملاً
- تحتوي على: درجة الخطورة، الخصائص، معلومات الجهاز
- يمكن استخدامها لمنع الوصول

### 4. Risk Score (درجة الخطورة)
- رقم من 0 إلى 100
- >= 80: عالية الخطورة → إنشاء بصمة
- < 80: منخفضة الخطورة → تجاهل

### 5. Status (الحالة)
- **ACTIVE:** بصمة نشطة → تمنع الوصول
- **BLOCKED:** تم تأكيد التهديد → حجب دائم
- **CLEARED:** تم إزالة المنع → لا تمنع الوصول

---

## 🎯 حالات الاستخدام الرئيسية

### 1. اكتشاف هجوم التحميل الجماعي
- المستخدم يحمل 20 ملفاً في ثانيتين
- النظام يكتشف النمط
- ينشئ بصمة عالية الخطورة

### 2. اكتشاف النقرات السريعة
- المستخدم ينقر 10 مرات على زر في ثانية
- `attachRapidClickDetector` يكتشف
- يرسل `ui_suspicious_pattern`

### 3. الحجب عبر المنصات
- سلوك مشبوه في توكلنا
- محاولة دخول أبشر → محجوب

### 4. إدارة البصمات
- المشغل يراجع البصمات
- يؤكد التهديدات أو يزيل المنع

---

## 🚀 الخطوات التالية (تحسينات مستقبلية)

1. **قاعدة بيانات حقيقية:**
   - استبدال التخزين في الذاكرة بـ PostgreSQL/MongoDB

2. **تحسين ML:**
   - تدريب نموذج أفضل
   - إضافة ميزات جديدة

3. **Real-time Updates:**
   - WebSockets للـ Dashboard
   - تحديث فوري بدون refresh

4. **Authentication:**
   - نظام تسجيل دخول حقيقي
   - JWT tokens

5. **Logging & Monitoring:**
   - سجلات مفصلة
   - مراقبة الأداء

---

## 📝 الخلاصة

هذا المشروع يوضح كيفية بناء نظام أمني متكامل لاكتشاف التهديدات السلوكية عبر المنصات الحكومية. يعتمد على:

- **تحليل سلوكي:** مراقبة الأنماط المشبوهة
- **ML + Rules:** كشف هجين
- **حجب عبر المنصات:** منع الوصول بناءً على البصمات
- **واجهة موحدة:** Dashboard واحد للعرض والإدارة

النظام جاهز للعرض التوضيحي ويمكن تطويره لبيئة إنتاجية.

---

**تاريخ الإنشاء:** 2024  
**الإصدار:** 1.0  
**الحالة:** جاهز للعرض التوضيحي

