# 🧪 دليل الاختبارات - Digital Threat Fingerprint

## 📋 نظرة عامة

هذا الدليل يشرح كيفية اختبار المشروع والتأكد من أن جميع المكونات تعمل بشكل صحيح.

---

## ✅ حالة الاختبارات

### الاختبارات المكتوبة:
- ✅ **test_storage.py** - اختبارات نظام التخزين
- ✅ **test_engine.py** - اختبارات محرك التحليل
- ✅ **test_api.py** - اختبارات API Endpoints

### الاختبارات اليدوية:
- ✅ اختبار تدفق الأحداث من Frontend
- ✅ اختبار إنشاء البصمات
- ✅ اختبار الحجب عبر المنصات
- ✅ اختبار Dashboard

---

## 🚀 تشغيل الاختبارات

### الطريقة 1: تشغيل جميع الاختبارات

```bash
cd backend
.\venv\Scripts\python.exe tests\run_tests.py
```

### الطريقة 2: تشغيل اختبارات محددة

```bash
cd backend
.\venv\Scripts\python.exe -m unittest tests.test_storage
.\venv\Scripts\python.exe -m unittest tests.test_engine
.\venv\Scripts\python.exe -m unittest tests.test_api
```

### الطريقة 3: تشغيل اختبار واحد

```bash
cd backend
.\venv\Scripts\python.exe -m unittest tests.test_storage.TestStorage.test_store_event
```

---

## 📝 الاختبارات المتوفرة

### 1. اختبارات التخزين (`test_storage.py`)

#### `test_store_event`
- **الهدف:** التحقق من حفظ الأحداث بشكل صحيح
- **المتوقع:** يتم حفظ الحدث في `EVENTS_STORE`

#### `test_store_fingerprint`
- **الهدف:** التحقق من حفظ البصمات
- **المتوقع:** يتم حفظ البصمة في `FINGERPRINTS_STORE`

#### `test_get_fingerprints`
- **الهدف:** التحقق من جلب جميع البصمات
- **المتوقع:** يتم إرجاع جميع البصمات المحفوظة

#### `test_update_fingerprint_status`
- **الهدف:** التحقق من تحديث حالة البصمة
- **المتوقع:** يتم تحديث الحالة بنجاح

#### `test_clear_user_fingerprints`
- **الهدف:** التحقق من مسح بصمات مستخدم
- **المتوقع:** يتم تغيير حالة جميع بصمات المستخدم إلى CLEARED

#### `test_delete_fingerprint`
- **الهدف:** التحقق من حذف بصمة
- **المتوقع:** يتم حذف البصمة من التخزين

---

### 2. اختبارات المحرك (`test_engine.py`)

#### `test_process_normal_event`
- **الهدف:** التحقق من معالجة حدث عادي
- **المتوقع:** لا يتم إنشاء بصمة للأحداث العادية

#### `test_process_rapid_events`
- **الهدف:** التحقق من كشف الأحداث السريعة
- **المتوقع:** يتم إنشاء بصمة عند اكتشاف أحداث سريعة

#### `test_calculate_behavioral_features`
- **الهدف:** التحقق من حساب الخصائص السلوكية
- **المتوقع:** يتم حساب الخصائص بشكل صحيح

#### `test_is_user_fingerprinted`
- **الهدف:** التحقق من وجود بصمة نشطة
- **المتوقع:** يتم اكتشاف البصمات النشطة فقط

#### `test_high_volume_attack`
- **الهدف:** التحقق من كشف هجمات الحجم العالي
- **المتوقع:** يتم إنشاء بصمة عند اكتشاف حجم عالي

---

### 3. اختبارات API (`test_api.py`)

#### `test_post_event`
- **الهدف:** التحقق من استقبال الأحداث
- **المتوقع:** يتم استقبال الحدث بنجاح (200)

#### `test_get_fingerprints`
- **الهدف:** التحقق من جلب البصمات
- **المتوقع:** يتم إرجاع قائمة البصمات (200)

#### `test_check_and_login_allowed`
- **الهدف:** التحقق من السماح بالدخول
- **المتوقع:** يتم السماح للمستخدم النظيف (200)

#### `test_check_and_login_blocked`
- **الهدف:** التحقق من حجب الدخول
- **المتوقع:** يتم حجب المستخدم المشبوه (403)

#### `test_confirm_threat`
- **الهدف:** التحقق من تأكيد التهديد
- **المتوقع:** يتم تغيير الحالة إلى BLOCKED (200)

#### `test_unblock_user`
- **الهدف:** التحقق من إزالة المنع
- **المتوقع:** يتم تغيير الحالة إلى CLEARED (200)

#### `test_delete_fingerprint`
- **الهدف:** التحقق من حذف البصمة
- **المتوقع:** يتم حذف البصمة بنجاح (200)

---

## 🧪 الاختبارات اليدوية (Manual Testing)

### 1. اختبار تدفق الأحداث

**الخطوات:**
1. تشغيل Backend:
   ```bash
   cd backend
   .\venv\Scripts\python.exe main.py
   ```

2. فتح صفحة توكلنا:
   ```
   http://localhost:5000/tawakkalna-login.html
   ```

3. فتح Developer Console (F12)

4. تسجيل الدخول

5. **التحقق من:**
   - ظهور `login_attempt` في Console
   - ظهور `login_success` في Console
   - استقبال الأحداث في Backend logs

**النتيجة المتوقعة:**
```
📥 [EVENT RECEIVED] Type: login_attempt, User: user-8456123848...
📥 [EVENT RECEIVED] Type: login_success, User: user-8456123848...
```

---

### 2. اختبار إنشاء البصمة

**الخطوات:**
1. فتح health-portal:
   ```
   http://localhost:5000/health-portal.html
   ```

2. النقر على زر "محاكاة هجوم التحميل الجماعي"

3. فتح Dashboard:
   ```
   http://localhost:5000/dashboard.html
   ```

4. **التحقق من:**
   - ظهور بصمة جديدة في الجدول
   - `risk_score >= 80`
   - `status: "ACTIVE"`
   - وجود `behavioral_features`

**النتيجة المتوقعة:**
- بصمة جديدة في Dashboard
- درجة خطورة عالية (>= 80)
- حالة ACTIVE

---

### 3. اختبار الحجب عبر المنصات

**الخطوات:**
1. إنشاء بصمة في توكلنا (كما في الاختبار السابق)

2. فتح صفحة أبشر:
   ```
   http://localhost:5000/absher-login.html
   ```

3. محاولة تسجيل الدخول

4. **التحقق من:**
   - ظهور overlay الحجب
   - رسالة "تم حجب دخولك مؤقتاً"
   - عدم السماح بتسجيل الدخول

**النتيجة المتوقعة:**
- Overlay كامل الشاشة مع رسالة الحجب
- لا يمكن تسجيل الدخول

---

### 4. اختبار Dashboard

**الخطوات:**
1. فتح Dashboard:
   ```
   http://localhost:5000/dashboard.html
   ```

2. **اختبار الأزرار:**
   - ✅ تأكيد التهديد → يجب أن تتغير الحالة إلى BLOCKED
   - 🔓 إزالة المنع → يجب أن تتغير الحالة إلى CLEARED
   - 🗑️ حذف → يجب أن تختفي البصمة

3. **التحقق من:**
   - تحديث الجدول تلقائياً
   - تحديث الإحصائيات
   - ظهور رسائل النجاح

**النتيجة المتوقعة:**
- جميع الأزرار تعمل بشكل صحيح
- التحديث التلقائي يعمل
- الإحصائيات دقيقة

---

## 📊 تقرير الاختبارات

### بعد تشغيل الاختبارات، ستحصل على تقرير مثل:

```
======================================================================
🚀 بدء تشغيل اختبارات Digital Threat Fingerprint
======================================================================

test_api (tests.test_api.TestAPI) ... ok
test_check_and_login_allowed (tests.test_api.TestAPI) ... ok
test_check_and_login_blocked (tests.test_api.TestAPI) ... ok
test_confirm_threat (tests.test_api.TestAPI) ... ok
test_delete_fingerprint (tests.test_api.TestAPI) ... ok
test_get_fingerprints (tests.test_api.TestAPI) ... ok
test_post_event (tests.test_api.TestAPI) ... ok
test_unblock_user (tests.test_api.TestAPI) ... ok
test_calculate_behavioral_features (tests.test_engine.TestEngine) ... ok
test_high_volume_attack (tests.test_engine.TestEngine) ... ok
test_is_user_fingerprinted (tests.test_engine.TestEngine) ... ok
test_is_user_fingerprinted_cleared (tests.test_engine.TestEngine) ... ok
test_process_normal_event (tests.test_engine.TestEngine) ... ok
test_process_rapid_events (tests.test_engine.TestEngine) ... ok
test_clear_user_fingerprints (tests.test_storage.TestStorage) ... ok
test_delete_fingerprint (tests.test_storage.TestStorage) ... ok
test_delete_nonexistent_fingerprint (tests.test_storage.TestStorage) ... ok
test_get_fingerprints (tests.test_storage.TestStorage) ... ok
test_store_event (tests.test_storage.TestStorage) ... ok
test_store_fingerprint (tests.test_storage.TestStorage) ... ok
test_update_fingerprint_status (tests.test_storage.TestStorage) ... ok
test_update_nonexistent_fingerprint (tests.test_storage.TestStorage) ... ok

----------------------------------------------------------------------
Ran 21 tests in 0.123s

OK

======================================================================
✅ جميع الاختبارات نجحت!
======================================================================
```

---

## 🔍 استكشاف الأخطاء

### إذا فشل اختبار:

1. **اقرأ رسالة الخطأ بعناية**
2. **تحقق من:**
   - أن Backend يعمل
   - أن جميع المكتبات مثبتة
   - أن المسارات صحيحة

3. **تشغيل اختبار واحد فقط:**
   ```bash
   .\venv\Scripts\python.exe -m unittest tests.test_storage.TestStorage.test_store_event -v
   ```

---

## 📈 تغطية الاختبارات

### المكونات المختبرة:
- ✅ نظام التخزين (storage.py)
- ✅ محرك التحليل (engine.py)
- ✅ API Endpoints (main.py)
- ✅ نماذج البيانات (models.py)

### المكونات التي تحتاج اختبارات إضافية:
- ⚠️ Frontend JavaScript (events.js)
- ⚠️ Integration Tests (End-to-End)
- ⚠️ Performance Tests

---

## 🎯 الخلاصة

المشروع يحتوي على:
- ✅ **21 اختبار تلقائي** للـ Backend
- ✅ **اختبارات يدوية** موثقة للـ Frontend
- ✅ **دليل اختبارات** شامل

**الحالة:** المشروع جاهز للاختبار والتحقق من جميع الوظائف الأساسية.

