# 🛡️ Digital Threat Fingerprint - دليل التشغيل

## ✅ الخطوات بعد تحميل النموذج

### 1. التحقق من وجود النموذج
تأكد من وجود الملف في:
```
ml/models/isoforest_absher.pkl
```

### 2. تشغيل السيرفر

#### الطريقة الأولى: استخدام ملف الباتش
```bash
START_SERVER.bat
```

#### الطريقة الثانية: من سطر الأوامر
```powershell
cd backend
python main.py
```

السيرفر سيعمل على: **http://localhost:5000**

### 3. فتح الواجهة

افتح المتصفح واذهب إلى:
- **Health Portal**: http://localhost:5000
- **Dashboard**: http://localhost:5000/dashboard.html

### 4. اختبار النظام

1. **في Health Portal**:
   - اضغط على أي خدمة (مثل "View Digital ID")
   - اضغط على "🚨 Trigger High-Speed Attack Simulation"
   - هذا سيرسل 20 حدث في ثانيتين لمحاكاة هجوم

2. **في Dashboard**:
   - راقب ظهور Threat Fingerprints
   - ستظهر البصمات المكتشفة مع Risk Score

## 🔧 استكشاف الأخطاء

### إذا لم يعمل السيرفر:

1. **تأكد من تثبيت المكتبات**:
   ```powershell
   .venv\Scripts\python.exe -m pip install -r requirements.txt
   ```

2. **تأكد من وجود النموذج**:
   ```powershell
   Test-Path "ml\models\isoforest_absher.pkl"
   ```
   يجب أن يعطي: `True`

3. **تحقق من الأخطاء في Terminal**:
   - اقرأ رسائل الخطأ بعناية
   - تأكد من أن البورت 5000 غير مستخدم

### إذا لم يكتشف النظام التهديدات:

1. تأكد من تشغيل "High-Speed Attack Simulation"
2. انتظر بضع ثوانٍ بعد المحاكاة
3. اضغط "Refresh" في Dashboard

## 📁 هيكل المشروع

```
hakathoon/
├── backend/
│   ├── main.py          # Flask API
│   ├── engine.py        # Threat Engine
│   ├── models.py        # Data Models
│   └── storage.py       # In-memory Storage
├── frontend/
│   ├── public/
│   │   ├── health-portal.html
│   │   └── dashboard.html
│   └── js/
│       ├── events.js
│       └── dashboard.js
├── ml/
│   ├── models/
│   │   └── isoforest_absher.pkl  ← النموذج هنا
│   └── notebooks/
│       └── train_isoforest.ipynb
└── requirements.txt
```

## 🎯 الميزات

- ✅ اكتشاف تلقائي للسلوكيات المشبوهة
- ✅ Risk Score من 0-100
- ✅ Dashboard لعرض البصمات المكتشفة
- ✅ محاكاة هجمات للاختبار

## 📞 الدعم

إذا واجهت أي مشاكل، تحقق من:
1. وجود النموذج في `ml/models/`
2. تثبيت جميع المكتبات
3. تشغيل السيرفر على البورت 5000

---

**جاهز للعرض! 🚀**

